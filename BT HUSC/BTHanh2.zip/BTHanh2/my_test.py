from my_functions import length,total,contains,find_item,count_item,reduce,filter_number,split_quotation

#1
n = length("[20, True, 'An']")
print(n)

#2
S = total("[20, 3, 5, 6]")
print(S)

#3
R = contains("[20, True, 'An']", True)
print(R)

#4
P = find_item("[20, True, 'An']", True)
print(P)

#5
n = count_item("[20, True, 'An']", True)
print(n)

#6
new_IP = reduce("192.168.011.002")
print(new_IP)

#7
# numbers_str = filter_number("5 + 5 = 10")
# print(numbers_str)
# "[5, 5, 10]"

#8
Q = split_quotation('What do you mean "That’s all"?')
print(Q)


    


