def length(list_str):
    cnt = 0
    for i in list_str:
        if i == ',':
            cnt = cnt + 1
    return cnt + 1
    
def total(list_str):
    str_t = ""
    list_r = []
    for i in list_str:
        if i >= '0' and i <= '9':
            str_t = str_t + i
        if i == ',' or i == ']':
            list_r.append(str_t)
            str_t = "" 
    sum = 0
    for i in list_r:
        if i != '':
            sum = sum + int(i)

    return sum


def contains(list_str,item):
    str_t = ""
    list_r = []
    for i in list_str:
        if i != ','and i != '[' and i != ']':
            str_t = str_t + i
        if i == ',' or i == ']':
            list_r.append(str_t)
            str_t = ""
    check = " "+ str(item)
    if check in list_r:
        return True
    else:
        return False
    
def find_item(list_str,item):
    str_t = ""
    list_r = []
    for i in list_str:
        if i != ','and i != '[' and i != ']':
            str_t = str_t + i
        if i == ',' or i == ']':
            list_r.append(str_t)
            str_t = ""
    check = False
    str_n = " " + str(item)
    for i in range(len(list_r)):
        if str_n == list_r[i]:
            check = True
            loc = i

    if check == True:
        return loc
    else:
        return -1


def count_item(list_str,item):
    str_t = ""
    list_r = []
    for i in list_str:
        if i != ','and i != '[' and i != ']':
            str_t = str_t + i
        if i == ',' or i == ']':
            list_r.append(str_t)
            str_t = ""
    cnt = 0
    str_n = " " + str(item)
    for i in range(len(list_r)):
        if str_n == list_r[i]:
            cnt = cnt + 1
            
    return cnt
def reduce(IPv4_address):
    str_n = ""
    for i in range(len(IPv4_address)):
        if IPv4_address[i] != '0':
            str_n = str_n + IPv4_address[i]
        
    return str_n

def filter_number():
    pass
def split_quotation(str):        
    str_n = ""
    list_str = list(str)
    for i in range(len(list_str)):
        if list_str[i] == '"':
            for j in range(i,len(list_str)-2):
                str_n = str_n + list_str[j+1]
                if list_str[j+2] == '"':
                    break
            
    return str_n